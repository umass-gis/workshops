This data pack contains geospatial files to follow along with the demo for the Learn the Basics of QGIS workshop in Fall 2022 (https://umass-gis.github.io/workshops/content/basics-qgis/).

Rebecca M. Seifried
(rseifried@umass.edu)
10/25/2022

***************
CONTENTS
***************

DCR_Stone_Walls.shp

Stone walls mapped by the Massachusetts Department of Conservation and Recreation (DCR). The original data is available as a feature service called "QWR StoneWalls Public View." The ArcGIS REST Server was added to QGIS and exported as a shapefile in the WGS84 UTM Zone 18N (EPSG:32618) CRS. Date of export: 10/25/22.

- Metadata: https://arcg.is/0eO5q9
- ArcGIS REST Server: https://services1.arcgis.com/7iJyYTjCtKsZS1LR/arcgis/rest/services/QWRStoneWalls_View/FeatureServer 


MA_Counties.shp

Massachusetts counties mapped by MassGIS. The original data is available to download in shapefile format from MassGIS. The shapefile COUNTIESSURVEY_POLYM was added to QGIS and exported as a shapefile in the NAD83 (EPSG:4269) CRS. Date of export: 10/25/2022.

- MassGIS website: https://www.mass.gov/info-details/massgis-data-counties


US_Canada.tif
Borders of the U.S. states and Canadian provinces. The original data is availalbe from Natural Earth. The shapefile "ne_10m_admin_1_states_provinces.shp" was added to QGIS and selected features were exported in shapefile format in the WGS84 (EPSG:4326) CRS.

- Natural Earth website: https://www.naturalearthdata.com/downloads/110m-cultural-vectors/

***************
ADDITIONAL LAYERS
***************

mufs190-1952-dpv1k80-i001.reference.tif

Georeferenced historical aerial photo of Dana Town Common in the Quabbin Reservoir. The photo is part of the MacConnell Aerial Photo Collection, courtesy Special Collections and University Archives (SCUA), University of Massachusetts Amherst Libraries. Date of acquisition: 6/8/1952. The photos was manually georeferenced by locating 12 ground control points against 2019 USGS satellite imagery and exported in GeoTIFF format in the NAD83 Massachusetts State Plane Mainland (EPSG:26986) CRS.

- SCUA website: https://credo.library.umass.edu/view/full/mufs190-1952-dpv1k80-i001
- Download from Google Drive: https://drive.google.com/file/d/17LXDZsHMpDaZRM90STg3kjYbSfdV5BCf/view?usp=sharing


LiDAR Hillshade
Statewide LiDAR data available as an image service from MassGIS (https://www.mass.gov/info-details/massgis-data-lidar-dem-and-shaded-relief).

- Metadata: https://arcg.is/0e8PmG2
- Image service URL: https://arcgisserver.digital.mass.gov/arcgisserver/rest/services/LiDAR/ShadedRelief_LiDAR/ImageServer


