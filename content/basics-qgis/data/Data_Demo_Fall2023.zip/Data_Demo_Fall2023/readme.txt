************************************
Data Pack for "Intro to QGIS"
************************************

Rebecca M. Seifried
(rseifried@umass.edu)
11 October 2023

This data pack contains sample GIS files for use in the workshop "Intro to QGIS," held as part of the UMass Amherst Libraries Fall 2023 Workshop Series. The files are not intended for distribution. If you would like to use these data in your work, you should check with the original publishers to make sure you are abiding by their licensing requirements.

-----------
CENSUS DATA
-----------
cb_2020_25_bg_500k_join.shp - Polygon shapefile of U.S. Census 2020 block groups in Massachusetts, downloaded from the Census' Cartographic Boundary Files (https://www.census.gov/geographies/mapping-files/time-series/geo/cartographic-boundary.html) and joined to the table ACS2020_Pop.xlsx (Data table from the American Community Survey Table B01003 - Total Population (https://data.census.gov/cedsci/table?q=b01003).

------------------
OPENSTREETMAP DATA
------------------
OSM_Supermarkets.shp - Point shapefile of features marked as "supermarkets" in the OpenStreetMap data as of today's date. The data was downloaded with the QuickOSM plugin and exported as a shapefile.


---------------------------------
NOT INCLUDED - SUGGESTED DOWNLOAD
---------------------------------
mump000-g3764-h6-1910-r5-i001.reference.tif - Georeferenced fire insurance map of Holyoke, MA, from 1910, downloaded from http://geodata.library.umass.edu/catalog/umass-mump000-g3764-h6-1910-r5-i001.


