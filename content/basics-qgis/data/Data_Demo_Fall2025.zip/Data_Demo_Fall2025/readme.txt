*************************************************
Data Pack for Learn the Basics of GIS
*************************************************

Rebecca M. Seifried
(rseifried@umass.edu)
October 20, 2025

This data pack contains sample GIS files for use in the workshop "Learn the Basics of GIS," held as part of the UMass Amherst Libraries' Workshop Series. The files are not intended for distribution. If you would like to use these data in your work, you should check with the original publishers to make sure you are abiding by their licensing requirements.


-------
CENSUS
-------
Cartographic Boundary file of U.S. County Subdivisions (i.e. towns) in 2022, 1:500,000 scale, with population data from Table P1 from the 2020 Decennial Census, and clipped to the state of Massachusetts. I manually cleaned the data table to prepare for joining to a shapefile in GIS, retaining only the GEOID and Total Population fields. In QGIS, I joined the data table to the original shapefile of county subdivisions, then selected only those subdivisions within Massachusetts and exported them as a new shapefile. Source (data table): DECENNIALDHC2020.P1_2024-03-13T100313, from https://data.census.gov/; Source (geography): https://www.census.gov/geographies/mapping-files/time-series/geo/cartographic-boundary.html

Access date: March 13, 2023
CRS: NAD83 (EPSG: 4269)


---------------
MASSGIS_AERIALS
---------------
MassGIS leaf-off orthoimagery of Massachusetts from 2019. The imagery was captured at 15cm resolution in 4 bands (RGB-IR). Only one tile of a portion of UMass Amherst campus was downloaded. Source: https://www.mass.gov/info-details/massgis-data-2019-aerial-imagery. 

Version date: Spring 2019
Access date: June 29, 2025
CRS: NAD 1983 (2011) UTM Zone 18N (EPSG: 6347)


-----------------
MASSGIS_LIBRARIES
-----------------
MassGIS point layer of libraries in the state of Massachusetts. Projected to WGS84 and converted from a shapefile to a geojson file for demonstration purposes. Source: https://www.mass.gov/info-details/massgis-data-libraries

Version date: April 2025
Access date: June 29, 2025
CRS: WGS84 (EPSG: 4326)


---------------
MASSGIS_SCHOOLS
---------------
MassGIS point layer of schools (pre-K through high school) in the state of Massachusetts. Source: https://www.mass.gov/info-details/massgis-data-massachusetts-schools-pre-k-through-high-school

Version date: October 10, 2024
Access date: June 29, 2025
CRS: NAD83 Massachusetts Mainland (EPSG: 26986)


---
NLCD
----
Excerpt from the National Land Cover Database (NLCD) 2024 of the area over Holyoke in central Massachusetts. The original raster covers the entire coterminous U.S. - the file is downloaded as an .img raster with a Coordinate Reference System of Albers_Conical_Equal_Area. The raster was clipped to the extent of the SRTM1 image below, then projected using the QGIS Warp (retroject) tool. Source: https://www.mrlc.gov/data

Version date: 2024
Access date: June 29, 2025
CRS: NAD83 Massachusetts Mainland (EPSG: 26986)

Additional files:
- NLCD_palette.qml - QGIS style file format, manually created to replicate the NLCD Land Cover Classification Legend.
- NLCD_Colour_Classification_Update.jpg - NLCD Land Cover Classification Legend.
- NLCDclasses.pdf - Land Cover Classification Legend and Description.


-----
SRTM
-----
Clip of an elevation tile over Holyoke in central Massachusetts, excerpted from the SRTM 1 Arc-Second Global (version 3) dataset. Source: https://earthexplorer.usgs.gov/. 

Access date: June 18, 2025
CRS: NAD83 Massachusetts Mainland (EPSG: 26986)



-----------------------------------------------------------
NOT INCLUDED BECAUSE OF FILESIZE LIMIT - SUGGESTED DOWNLOAD
-----------------------------------------------------------

Fire insurance map: Georeferenced fire insurance map of Holyoke, MA, from 1910, downloaded from https://geodata.library.umass.edu/catalog/umass-mump000-g3764-h6-1910-r5-i001
