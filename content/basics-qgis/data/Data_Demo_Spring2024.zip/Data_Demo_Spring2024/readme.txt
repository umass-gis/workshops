************************************
Data Pack for "Intro to QGIS"
************************************

Rebecca M. Seifried
(rseifried@umass.edu)
March 13, 2024

This data pack contains sample GIS files for use in the workshop "Intro to QGIS," held as part of the UMass Amherst Libraries Spring 2024 Workshop Series. The files are not intended for distribution. If you would like to use these data in your work, you should check with the original publishers to make sure you are abiding by their licensing requirements.


-----------
CENSUS DATA
-----------

cb_2022_us_state_500k.shp
States in the US, from the US Census Bureau's Cartographic Boundaries (https://www.census.gov/geographies/mapping-files/time-series/geo/cartographic-boundary.html). Used for displaying and demonstrating basic vector data.


DECENNIALDHC2020.P1_2024-03-13T100313
Table P1 from the 2020 census for county subdivisions, with total population. I manually cleaned the file in preparation for joining to cb_2022_us_cousub_500k.shp (see below). 

How to join this table to the county subdivision shapefile:
1. Add DECENNIALDHC2020.P1-Data_edit.csv to QGIS
2. Download the county subdivision shapefile (see below) and add to QGIS
3. Right-click the shapefile and select "Properties"
4. Navigate to the Joins menu
5. Click the green plus icon (+) to add a new join
  a. Join layer = the .csv data table
  b. Join field = GEO_ID
  c. Target field = AFFGEOID
  d. Click "OK"
6. Open the shapefile's attribute table. Scroll all the way to the right to confirm that the data table was successfully joined to the shapefile.


-----------------------------------------------------------
NOT INCLUDED BECAUSE OF FILESIZE LIMIT - SUGGESTED DOWNLOAD
-----------------------------------------------------------

cb_2022_us_cousub_500k.shp
County subdivisions (i.e. towns), from the US Census Bureau's Cartographic Boundaries (https://www.census.gov/geographies/mapping-files/time-series/geo/cartographic-boundary.html). Note that I joined the data table below so that I could show how to use categorical symbology.


mump000-g3764-h6-1910-r5-i001.reference.tif - Georeferenced fire insurance map of Holyoke, MA, from 1910, downloaded from https://geodata.library.umass.edu/catalog/umass-mump000-g3764-h6-1910-r5-i001


Lidar_Elevation_2013to2021_11.img - Lidar digital elevation model (DEM) from MassGIS. The tile I show in the recording is tile number 11. Downloaded from https://www.mass.gov/info-details/massgis-data-lidar-terrain-data. Recommended web app to easily download individual tiles: https://massgis.maps.arcgis.com/apps/instant/basic/index.html?appid=74fc33f4d479498cab2a5ac99af20e83
