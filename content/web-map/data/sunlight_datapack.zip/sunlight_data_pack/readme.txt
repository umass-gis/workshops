
******************
Sunlight Data Pack
******************

This data pack contains two files: 

'uscities_1000_sunlight.csv' - a CSV with information about the 1,000 largest cities in the U.S.

'uscities_mainland.shp' - a shapefile generated from the CSV, with additional fields in the attribute table that were calculated for improved display.

The cities data comes from SimpleMaps' US Cities Database (https://simplemaps.com/data/us-cities). It was downloaded for free with the requirement that a backlink be placed on the public webpage where the Customer is using the data. The original data contained the following fields:
- city
- city_ascii
- state_id
- state_name
- county_fips
- county_name
- lat
- lng
- population
- density
- source
- military
- incorporated
- timezone
- ranking
- zips
- id

Using a custom Python script (available in this GitHub repo, https://github.com/umass-gis/workshops), the Sunrise Sunset API (https://sunrise-sunset.org/api) was used to collect the sunrise, sunset, and day length values for each location on 12/21/2022. 

This data pack is licensed with an Attribution 4.0 International (CC BY 4.0) license (https://creativecommons.org/licenses/by/4.0/). Credit must be also given to SimpleMaps and Sunrise-Sunset.org.

Rebecca M. Seifried
(rseifried@umass.edu)
22 March 2022